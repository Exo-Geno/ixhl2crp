--If you wish to contribute to translation, you may do so here.

ix.lang.stored.english['rotateItem'] = 'Rotate'
ix.lang.stored.english['rotateNotAllowed'] = 'This inventory cannot fit the rotated version of this item! (%sx%s)'

ix.lang.stored.russian['rotateItem'] = 'Повернуть'
ix.lang.stored.russian['rotateNotAllowed'] = 'Этот инвентарь не подходит для повернутой версии этого предмета! (%sx%s)'

ix.lang.stored.korean['rotateItem'] = '회전'
ix.lang.stored.korean['rotateNotAllowed'] = '이 아이템을 회전시킬 경우 인벤토리에 들어맞지 않습니다! (%sx%s)'
