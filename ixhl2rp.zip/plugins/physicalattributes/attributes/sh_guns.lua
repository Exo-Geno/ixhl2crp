ATTRIBUTE.name = "Gun crafting"
ATTRIBUTE.category = "Professions"
ATTRIBUTE.description = "The skill to craft more complex weapons."