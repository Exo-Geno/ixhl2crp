ATTRIBUTE.name = "Aim"
ATTRIBUTE.description = "Shooting and aim skill."