ATTRIBUTE.name = "Cooking"
ATTRIBUTE.category = "Proffesions"
ATTRIBUTE.description = "The ability to cook like a chef."