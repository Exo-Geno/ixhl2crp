ATTRIBUTE.name = "Dextery"
ATTRIBUTE.description = "Skill in performing tasks, especially with the hands."
