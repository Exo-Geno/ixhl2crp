ATTRIBUTE.name = "Technology"
ATTRIBUTE.category = "Professions"
ATTRIBUTE.description = "The application of scientific knowledge for practical purposes."