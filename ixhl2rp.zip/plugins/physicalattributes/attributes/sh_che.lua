
ATTRIBUTE.name = "Chemistry"
ATTRIBUTE.category = "Professions"
ATTRIBUTE.description = "The skill of investigating properties and reactions of some substances."