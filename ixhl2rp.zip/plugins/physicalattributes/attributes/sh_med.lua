ATTRIBUTE.name = "Medical Knowledge"
ATTRIBUTE.description = "The body of information about diseases, mechanisms and pathogenesis, therapies and interactions."
