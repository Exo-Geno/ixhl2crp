
ATTRIBUTE.name = "Computing"
ATTRIBUTE.category = "Professions"
ATTRIBUTE.description = "Software and programming skills."