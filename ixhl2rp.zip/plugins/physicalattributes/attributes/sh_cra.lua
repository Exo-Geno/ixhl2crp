ATTRIBUTE.name = "Handy"
ATTRIBUTE.description = "The skill to craft some things, specially with the hands."
ATTRIBUTE.category = "Proffesions"