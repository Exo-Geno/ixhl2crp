local PLUGIN = PLUGIN

PLUGIN.name = "MoneyChangeModel"
PLUGIN.author = "Usuariozombie"
PLUGIN.description = "Simple, it just change tokens model without editing helix plugins."

ix.currency.model = "models/bioshockinfinite/hext_coin.mdl"