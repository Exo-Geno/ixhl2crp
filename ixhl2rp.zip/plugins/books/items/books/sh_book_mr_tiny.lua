ITEM.name = "The Sweet Release"
ITEM.model = Model("models/props_lab/binderblue.mdl")
ITEM.description = "This book is dirty and is generally pretty beaten up."
ITEM.price = 10

ITEM.text = [[
There's so many wonderful things in life, but what the most beautiful thing is is a sweet release, a mix of emotions that can really set you apart from the world and to your own mind. You will find this emotion to be really satisfying once it finally happens, and we can lead you to this satisfying feeling if you just follow our path...

Every time you find a skull, there will be an item next to it. Under no circumstances, you shall not: 
use it 
consume it
trade it away
throw it away. 
If you commit any of the above, you have betrayed our trust, and you won't feel this satisfying feeling. Hold these items dear to your heart, if anyone else carries these items, you stick to together, and feel this amazing feeling together. Once you get the feeling, you won't get enough of it. You will love it, you will...

*The test of the pages seems to be covered up with: "You will love it."

*At the end of the pages, there is some text, one of the words seems jumbled up.*

It is D%#$h.
]]