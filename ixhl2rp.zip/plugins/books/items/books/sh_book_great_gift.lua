ITEM.name = "3001, Collaboration: The Greatest Gift"
ITEM.model = Model("models/props_lab/binderbluelabel.mdl")
ITEM.description = "A gray book with a dark red Union symbol on it."
ITEM.price = 10

ITEM.text = [[
<font color='red' size='4'>Written by City Twenty Four Administrator: Alfred Hunter.</font>

Dear Reader,
I write from City 24, due to many requests from readers of my previous book, I have chosen to write a new book which would be transported across all the cities of the Union.
Like the previous book I have published, this one will focus around the Universal Union.  

The Universal Union is a large empire, which spreads across the Galaxy beyond human's reach. Earth is one of the destinations the empire has reached and occupied. 
Humanity has been gifted the benefits of protection from the Universal Union, the Metro Police Force, which maintains the stability within the City limits.
And the Elite Soldier arm, which assists upon critical stability within the city. The Universal Union provided these arms to secure the cities, contain threats and protect us.

In my previous book, have I explained that the civilization has grown smaller since the arrival of the Universal Union to Earth. But great things require great sacrifices.
With the decrease of the population on Earth, the Union provides the technology they posses, such as futuristic medicine, advanced supplies for the armed forces stated above and such.
The Union allows us to live in equality, each citizen is given a fair start and conditions. Pre-War citizens who were homeless now own clothes, a home, food and protection.
Each citizen is given equal rights, and as they improve, their rights expand.

As I have summed up the important parts of my book, I wish to get in topic, I wish to discuss the sickness of our society: The Rebellion. You reader, may have heard of the Rebellion,
the one's responsible for the destruction of the Union's trust to us, the citizens. It is but simple math, the more the rebels act against the Union, the more we the citizens have to suffer.
The rebels are mentally unstable, they are untrusted and will betray their allies for the sake of their own. It is the Rebellion that betrayed the lives of the citizens, who get affected by their reign of terror.
The rebels are sick, and fight against humanity's future, against our evolution. 

I wish to share an experience of my own. I once had a daughter, her name was Sophia. Once I was assigned to the City Administration, had I started to get less opportunities to stay in touch with her.
Sophia was kidnapped and manipulated into a group of cultists. Shortly enough she subsumed herself to the cult and became a rebel herself. Once I found out, I had to order an arrest on her.
She gave up the hope which we all have in trusting our benefactors. My own daughter had fallen into the dip of rebel cancer which plagues our city. And as collaborators of our Union 
which consist of mutual workers of the Union such as the strong cells within us, we had to do what was necessary to our system. I share this story to show that no one can use action against the Universal Union,
our collaborators, and not expect consequences, not even the closest ones.


This comes to conclude, that the Union will do all in it's powers to fight for the purity of humanity and the Resistance will not be able to avoid it. The Universal Union will hunt the Resistance, 
it will not stop until every last terrorist has been killed. <font size='4'>Until the Resistance will extinct!</font>

Glory to the Union!
]]
  
