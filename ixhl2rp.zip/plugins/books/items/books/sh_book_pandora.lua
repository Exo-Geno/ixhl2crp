ITEM.name = "Pandora Tomorrow"
ITEM.model = Model("models/props_lab/binderbluelabel.mdl")
ITEM.description = "An old book written on recycled paper."
ITEM.price = 10

ITEM.text = [[
<font color='red' size='4'>'Napoleon'</font>

Let me share something with you.

The human brain is a Pandora's box of electrical charges which we can only begin to understand. 
Encoding is the first step in creating a memory. It's a biological phenomenon, rooted in the senses. Each of the sensations travel to the part of our brain called the hippocampus, which integrates these perceptions as they are occurring into one single experience.
It is believed that the hippocampus, along with another part of the brain called the frontal cortex, is responsible for analyzing these various sensory inputs and deciding if they're worth remembering. If they are, they may become part of your long-term memory. As indicated earlier, these various bits of information are then stored in different parts of the brain. How these bits and pieces are later identified and retrieved to form a cohesive memory, however, is not yet known by human science.

Human science. As I am about to explain, the Combine not only know but use it to terrible effect.

The Combine have devices they refer to as Memory Replacement Devices. With it, they can replace your thoughts and memories with anything that pleases them. 
They will construct these devices everywhere, use them on anyone who allows them to. In the end, humanity will be theirs. Mind, body, and if they desire it, soul. 
]]