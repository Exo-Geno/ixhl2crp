ITEM.name = "Nlaw Them"
ITEM.model = Model("models/props_lab/frame002a.mdl")
ITEM.description = "A picture containing three strange figures."
ITEM.price = 32

ITEM.text = [[
<img src = "https://i.imgur.com/gbBaeFB.jpg" width="480" height="480"/>
]]