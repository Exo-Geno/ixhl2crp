ITEM.name = "Line 32"
ITEM.model = Model("models/props_lab/bindergraylabel01a.mdl")
ITEM.description = "A worn book. Smells musky."
ITEM.price = 32

ITEM.text = [[
<font color='red' size='4'>Written by Unknown.</font>

... Do you know of the lamp? The one in that room, up on the catwalks. The lamp wants YOU to listen to its demands, to follow its every order. They might call me crazy but I am the one who has been illuminated by its wisdom. 

If you see the lamp, it means YOU have been chosen, listen to it and be illuminated like me. For the lamp wants nothing but our loyalty, in exchange for its gift of knowledge. Those who ignore the lamp's words of wisdom are fools, so we must convince them of their blasphemy.

That is why I speak for the lamp and its followers, to convince the non believers of our cause. All who know of the lamp's wisdom must attempt to convince the non believers of the lamp's plans of illuminating our minds.

When you meet one of these non believers, I want you to quote the pale man, the first follower of his cause, as it states on his holy writing... "Let there be light."

For believe me brothers, there WILL be light on the day that his plans come to fruition.
]]