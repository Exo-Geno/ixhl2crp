ITEM.name = "The Red Book of Riddles"
ITEM.model = Model("models/props_lab/binderredlabel.mdl")
ITEM.description = "A red book with 'Riddles' written on the front."
ITEM.price = 10

ITEM.text = [[
<font color='red' size='4'>Written by Lynne Jane.</font>

For earnest pleasure, and the strengthening of the mind, the author here collects all that she has learned of the art of riddling, by dint of diligent study, and through years of discourse with others of similar inclination.

The Question

An eye in a blue face
Saw an eye in a green face.
�That eye is like to this eye�
Said the first eye,
�but in low place
Not in high place.�

seisaid eht no nus ehT :rewsnA ehT

The Question

I'm left behind yet never taken, set down in a row.
Seldom seen in isolation, captured by the snow.
Set apart by haste, though immobile all the same.
When left un-defaced, a betrayal of the game.

Stnirptoof :rewsnA ehT

The Question

It cannot be seen, cannot be felt,
Cannot be heard, cannot be smelt.
It lies behind stars and under hills,
And empty holes it fills.
It comes first and follows after,
Ends life, kills laughter.

ssenkrad :rewsnA ehT

The Question

Born of the cold and born of the heat.
Pacing the world on legs oh so fleet.
Swiftest up high, lethargic down low.
The actions are seen, the form does not show.

dniW :rewsnA ehT

The Question

A metal neither black nor red
As heavy as man's golden greed
What you do to stay ahead
With friend or bullet or steed

dael :rewsnA ehT

The Question

A box without hinges, key, or lid,
yet golden treasure inside is hid.

ggE :rewsnA ehT

The Question

A man says, "If you lie to me I will slay you with my knife. If you tell me the truth, I will slay you with a gun." What must you say to stay alive?

.efink a htiw em yals lliw uoY :rewsnA ehT

The Question:

Thirty white horses on a red hill,
First they champ,
Then they stamp,
Then they stand still.

hteeT :rewsnaA ehT

The Question:

A Citizen was slain. The Loyalist claims the Civil Worker is guilty. The Civil Worker says the Unit did it. The Doctor swears he didn't kill the Citizen. The Unit says the Worker is lying. If only one of these speaks the truth, who killed the Citizen?

rotcoD ehT :rewsnA ehT

The Question

With twelve eggs on order, the cook sat and thought.
"One at a time if I like it or not."
With three in the freezer and three in the pot,
Three in each hand neither too cold nor hot.
The first two were airy, or so he remembers,
The last two both burnt up and ended in embers.

raeY eht fo shtnoM ehT :rewsnA ehT

The Question:

Voiceless it cries,
Wingless flutters,
toothless bites,
Mouthless mutters.

dniW  :rewsnA ehT

The Question

A pallid visage in plain sight revealed by its foe.
It does not fast, it does not feast, and yet does shrink and grow.
Much grander and yet more minute than those it stands beside.
Unendingly stalking around, a circuitous stride.

Noom :rewsnA ehT

The Question:

Alive without breath,
As cold as death;
Never thirsty, ever drinking,
All in mail never clinking.

hsiF :rewsnA ehT

The question:

Poets know the hearts of Men laid bare
But beasts can't know my heart, you see
This book was written by a bear
And so...

yrteop fo koob a ton si tI :rewsnA ehT

The Question

What has roots as nobody sees,
Is taller than trees,
Up, up it goes,
And yet never grows?

niatnouM :rewsnA ehT

The Question

A bound serpent dances on the cave floor.
Writhing guardsman of the windy door.
Sharp yet supple and mute yet speaking.
Devoid of hunger, nourishment seeking.

eugnoT :rewsnA ehT

The Question

Ceaseless blur or rigid banner varying by host.
On the smallest scale less substantial than a ghost.
Commonplace yet pivotal to rise above it all.
As a pair they triumph yet once separated fall.

sgniW :rewsnA ehT

The Question

This thing all things devours:
Birds, beasts, trees, flowers;
Gnaws iron, bites steel;
Grinds hard stones to meal;
Slays king, ruins town,
And beats high mountain down.

emiT :rewsnA ehT

The Question

Unlike other rulers I am strengthened by neglect.
Over my jurisdiction, great taxes I elect.
When routine dues are paid, I am weakened severely.
Yet if too long delayed, it may cost you quite dearly.
My vault is of the flesh, my tellers silver and bone.
The upkeep of the kingdom is financed with a loan.

regnuH :rewsnA ehT

The Question

Amy, Sara, Mary, Laura and Danielle attended a dinner party.

The women sat in a row. They all wore different colours and Amy wore a jaunty Blue hat. Sara was at the far left, next to the guest wearing a White jacket. The lady in Red sat left of someone in Black. I remember that Red outfit because the woman spilled her Gin all over it. The traveler from City 17 was dressed entirely in Orange. When one dinner guest bragged about her Ring, the woman next to her said they finer in City 17, where she lived.

So Mary showed off a prized Necklace, at which the lady from City 8 scoffed, saying it was no match for her Pendant. Someone else carried a valuable Watch and when she saw it, the visitor from City 18 next to her almost spilt her neighbour�s Beer. Laura raised her Wine in toast. The lady from City 5, full of Vodka, jumped up onto the table, falling onto the guest at the centre seat, spilling the poor woman�s Punch. Then Danielle captivated them all with a story about her wild youth in City 10.

In the morning, the Ring, the Necklace, the Pendant and the Watch were all under the table - but who did each belong to?

tnadneP - ymA
hctaW - araS
ecalkceN - yraM
gniR - aruaL
]]