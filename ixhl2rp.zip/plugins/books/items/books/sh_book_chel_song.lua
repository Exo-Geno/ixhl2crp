ITEM.name = "Song for Chel"
ITEM.model = Model("models/props_lab/binderbluelabel.mdl")
ITEM.description = "A blue book with a spiralling logo with notes."
ITEM.price = 48

ITEM.text = [[
<font color='red' size='4'>For Chel.</font>

Songs of Praise to Chel:

[Chel for]

He is mighty
He is pure
Chel for he
Chel for her
Chel defeats
Chel, victor

I have no needs
For Chel
This heart beats

[Take my]

Take my LP
Take my coin

Take my soul
Take my joy

Oh Chel above
Oh Chel on Terra

Take my food
For you are my mana

[Enemies]

Those who despise
Those who conspire

Against The Chel
Those deaths I desire

Enemies of Chel
Them I’ll fel

With sword, with, gun
With fist, what fun.

Enemies of Chel
They shall burn in Hell

[My Chel]

Chel I am yours
Chel you are mine

I wish to see your true form
To see the Valhalla Idemu fought for


Chel is mine
I am his

My Chel
My bell
My god
]]