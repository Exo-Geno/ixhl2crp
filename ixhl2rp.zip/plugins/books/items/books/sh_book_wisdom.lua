ITEM.name = "Wisdom"
ITEM.model = Model("models/props_lab/binderredlabel.mdl")
ITEM.description = "A red book with a yellow Union symbol on the front."
ITEM.price = 20

ITEM.text = [[
<font color='red' size='4'>Written by Charles J. Arthus II.</font>

Summary: In this piece of fine literature we will discuss some basic things you may hear when living in a city under Union occupation, fear not I your Author will guide  you by the hand as we take a look at some simple terms we hear far too often in the glorious commonwealths of the Universal Union.

C:ooperation
L:oyalty
A:dmiration
M:utual Respect
P:articipation

Just above I've spelled out a simple word many of you have probaby heard over the PA system from the lovely lady who instructs us day to day. I have assessed the word many times and come to determine these are the core values they expect us to uphold during a time which it may be broadcasted or said by a unit.

C:aution
A:ptitude
U:nity
T:rust
E:nigma
R:esponsibility
I:nterest
Z:en
E:rosion

I've taken the liberty of spelling out another word which I believe holds great power within our gloryful Union, as you can see these are steps to take and ideals to have in mind if you hear this word used on your location. Remember Civil Protection Forces are here to help, and with your full cooperation we can attain full ration status! How exciting is it not?

S:ociostability
T:emptation
E:rase
R:evitalize
I:ntrospective
L:iability
I:ntelligence
Z:en
E:radication

I've saved the most serious for last, I've had the displeasure of being present for many 'sterilizations'during the time this is broadcasted or said by any unit within your vicinity it would be in your best interest to cooperate the fullest, for it is the time they are usually displaying excessive if not overwhelming force. Please remember you are a competent citizen of the Universal Union, always strive for greatness and unity within your designated district. For more information on commonly used phrases please see book two 'Intelligence.'
]]