ITEM.name = "What mama used to say..."
ITEM.model = Model("models/props_lab/binderbluelabel.mdl")
ITEM.description = "A new looking book."
ITEM.price = 20

ITEM.text = [[
<font color='red' size='4'>Written by Peter.</font>

I didn't remember our lives being this bad. We started out pretty good � lots of toys and games and fun. But then I could tell mom and dad were running into troubles. They stopped buying us things every week, we didn't have as much candy in the cabinets and we hadn't even been on a trip in a long time. Dad would always yell, or shout, or knock things around. Especially every time I saw him looking at his computer with all those numbers and $$$ signs. They talked about needing dollars a lot. And when dad got really going, when he would read me my favorite bedtime story about a giant and a beanstalk, he would laugh to me, �Yeah, if only we had one of those! Huh!�



But then, I remembered what mama used to say. It was about my little brother Alfie. How sweet he was, how kind, how funny he was. The little guy would always smile, try to put away all his toys, and would rarely even cry at night time. Man, we loved that! But� that wasn't the thing that mama used to say.



I walked into the kitchen, placing the trash bag down on the table with a soft thud where my mother was sitting nearby. I was kind of mad. You see, my mom usually didn't lie to me. So I wondered why she had this time. It didn't make any sense.



�Why did you lie to me, mommy?� I asked her.



�What do you mean, honey?� She smiled back at me.



I pointed at the bag. It was then that she looked into it, and I saw her get a really scared face. She even put a hand over her mouth, sucking in air.



�Why mommy?� I asked again. She hadn't moved, not even an inch or made a sound.



I shrugged my shoulders a little, watching my mother as I told her angrily:



�Little Alfie didn't have a heart of gold!�
]]