
FACTION.name = "Sector 32 Universal Union Armed Forces"
FACTION.description = "A regular human citizen enslaved by the Universal Union. They're now a soldier"
FACTION.color = Color(255, 128, 0)
FACTION.isDefault = false
FACTION.models = {
	"models/yukon/conscripts/conscript_a_w_friendly_v2.mdl",
    "models/yukon/conscripts/conscript_a_b_friendly_v2.mdl"
}


FACTION_CONSCRIPT = FACTION.index
